package com.automotive.amptric;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Settings extends AppCompatActivity {
    View Lang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);


        Lang = findViewById(R.id.lang);


        Lang.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                PopupMenu popup = new PopupMenu(Settings.this, Lang);
                popup.getMenuInflater().inflate(R.menu.languages,popup.getMenu());
                popup.show();
            }
        });

    }

    @Override
    public void onBackPressed(){

        Intent iHome = new Intent( Settings.this, MainActivity.class);
        startActivity(iHome);


    }
}