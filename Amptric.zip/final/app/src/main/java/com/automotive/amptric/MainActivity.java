package com.automotive.amptric;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.res.ResourcesCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;


public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;

    TextView button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        View navDash, navChar, navTrip, navDoc, navMore;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        navigationView = findViewById(R.id.NavigationView);
        drawerLayout = findViewById(R.id.drawerLayout);
        toolbar = findViewById(R.id.app_bar);


        setSupportActionBar(toolbar);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

       // drawer click start

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();

                if (id==R.id.item1){

                    Intent iHome = new Intent(MainActivity.this, Profile.class);
                    startActivity(iHome);

                } else if (id==R.id.item2) {

                    Intent iHome = new Intent(MainActivity.this, Settings.class);
                    startActivity(iHome);


                } else if (id==R.id.item3) {

                } else if (id==R.id.item4) {

                    Intent iHome = new Intent(MainActivity.this, About.class);
                    startActivity(iHome);
                }else {

                }

                return true;
            }
        });
//drwer click end

     /*   toolbar.post(new Runnable() {
            @Override
            public void run() {
                Drawable d = ResourcesCompat.getDrawable(getResources(), R.mipmap.user_i_foreground, null);
                toolbar.setNavigationIcon(d);
            }
        });
*/

        navDash = findViewById(R.id.navDash);
        navChar = findViewById(R.id.navChar);
        navTrip = findViewById(R.id.navTrip);
        navDoc = findViewById(R.id.navDoc);
        navMore = findViewById(R.id.navMore);


        navMore.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                PopupMenu popup = new PopupMenu(MainActivity.this, navMore);
                popup.getMenuInflater().inflate(R.menu.more,popup.getMenu());
                popup.show();
            }
        });




        navDash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                replaceFragment(new DashB());
            }
        });



        navChar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                replaceFragment(new ChargingStation());
            }
        });



        navTrip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                replaceFragment(new MyTrip());
            }
        });



        navDoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                replaceFragment(new DocsLibrary());
            }
        });



    }


//fragment transaction start
    private void replaceFragment(Fragment fragment) {


        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.activeFrame, fragment);
        fragmentTransaction.commit();

    }

//fragment transaction end

    //Back press locked  start
    @Override
    public void onBackPressed()
    {

        AlertDialog.Builder exit = new AlertDialog.Builder(MainActivity.this);
        exit.setMessage("Exit App");
        exit.setMessage("Do you want exit the app?");
        exit.setIcon(R.mipmap.ic_launcher);
        exit.setPositiveButton("Yes", new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // exit code
                finishAffinity();

            }
        });

        exit.setNegativeButton("No", new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Cancel exit
                dialogInterface.dismiss();
            }
        });
        exit.show();

    }
//Back press lock end


}